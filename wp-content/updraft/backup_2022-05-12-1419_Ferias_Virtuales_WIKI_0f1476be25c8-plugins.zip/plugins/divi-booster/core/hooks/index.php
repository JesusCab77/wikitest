<?php 

// Load the hooks
$HOOKDIR = dirname(__FILE__).'/';

include_once($HOOKDIR.'action-db_admin_css.php');
include_once($HOOKDIR.'action-db_admin_jquery.php');
include_once($HOOKDIR.'action-db_head_js.php');
include_once($HOOKDIR.'action-db_user_jquery.php');
include_once($HOOKDIR.'action-db_vb_css.php');
include_once($HOOKDIR.'action-db_vb_head.php');
include_once($HOOKDIR.'action-db_vb_jquery.php');
include_once($HOOKDIR.'filter-db_builder_should_load_framework.php');
include_once($HOOKDIR.'filter-dbdb_get_extended_font_icon_symbols.php');
include_once($HOOKDIR.'filter-dbdb_et_pb_get_font_down_icon_symbols.php');
include_once($HOOKDIR.'filter-dbdb_filterable_portfolio_tabs_terms.php');
include_once($HOOKDIR.'filter-dbdb_render_slug_shortcode_output.php');
