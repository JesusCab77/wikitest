<?php
if (!defined('ABSPATH')) { exit(); } // No direct access
?>
#page-container { overflow:hidden; }