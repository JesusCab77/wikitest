<?php
if (!defined('ABSPATH')) { exit(); } // No direct access
?>
jQuery(function($){
	$('.et_pb_more_button').attr('target', '_blank');
});