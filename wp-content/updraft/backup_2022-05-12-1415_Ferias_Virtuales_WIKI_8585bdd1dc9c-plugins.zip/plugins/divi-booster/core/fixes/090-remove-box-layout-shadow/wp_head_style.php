<?php
if (!defined('ABSPATH')) { exit(); } // No direct access
?>
#page-container, #wtfdivi004-page-start-img { 
	-moz-box-shadow:none !important; 
	-webkit-box-shadow:none !important; 
	box-shadow:none !important; 
}