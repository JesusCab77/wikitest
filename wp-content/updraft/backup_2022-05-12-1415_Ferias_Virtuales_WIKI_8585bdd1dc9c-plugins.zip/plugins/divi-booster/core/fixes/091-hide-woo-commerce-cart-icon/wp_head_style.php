<?php
if (!defined('ABSPATH')) { exit(); } // No direct access
?>
.et-cart-info { display:none !important; }