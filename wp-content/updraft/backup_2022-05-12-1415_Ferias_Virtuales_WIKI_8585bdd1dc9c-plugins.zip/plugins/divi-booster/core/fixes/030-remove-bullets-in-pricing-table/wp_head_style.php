<?php 
if (!defined('ABSPATH')) { exit(); } // No direct access
?>
.et_pb_pricing li:before,
.et_pb_pricing li span:before { 
	display:none; 
}