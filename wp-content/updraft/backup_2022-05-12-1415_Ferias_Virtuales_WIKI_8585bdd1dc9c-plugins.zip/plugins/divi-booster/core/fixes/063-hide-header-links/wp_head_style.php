<?php
if (!defined('ABSPATH')) { exit(); } // No direct access
?>
/* Hide the header navigation links */
#et-top-navigation { 
    visibility: hidden; 
}
/* Don't hide the centered inline logo */
#et-top-navigation .centered-inline-logo-wrap {
    visibility: visible;
}