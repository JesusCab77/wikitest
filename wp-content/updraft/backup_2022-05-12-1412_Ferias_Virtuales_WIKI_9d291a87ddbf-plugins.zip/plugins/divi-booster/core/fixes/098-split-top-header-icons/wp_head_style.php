<?php
if (!defined('ABSPATH')) { exit(); } // No direct access
?>
/* Hide while still on left */
@media only screen and (min-width: 981px) {
	#et-info #et-social-icons,
	#et-info .et-social-icons { 
		display: none; 
	}
}