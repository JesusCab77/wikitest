<?php
if (!defined('ABSPATH')) { exit(); } // No direct access
?>
.et_pb_pricing li.et_pb_not_available {
	text-decoration: line-through;
}