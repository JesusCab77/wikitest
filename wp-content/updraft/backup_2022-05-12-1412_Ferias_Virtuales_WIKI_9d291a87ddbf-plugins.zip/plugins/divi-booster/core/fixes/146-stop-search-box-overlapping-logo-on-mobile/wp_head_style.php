<?php
if (!defined('ABSPATH')) { exit(); } // No direct access
?>
@media only screen and (max-width: 980px) {
	#main-header .et-search-field { 
		max-width: calc(100% - 30px);
	}
	#main-header .et-search-form {
		max-width: calc(50% - 16px) !important
	}
}
