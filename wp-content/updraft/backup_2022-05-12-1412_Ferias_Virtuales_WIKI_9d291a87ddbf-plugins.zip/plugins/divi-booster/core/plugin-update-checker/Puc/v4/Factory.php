<?php
namespace DiviBooster;

if ( !class_exists('\DiviBooster\Puc_v4_Factory', false) ):

	class Puc_v4_Factory extends Puc_v4p10_Factory { }

endif;
