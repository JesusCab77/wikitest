<?php
if (!defined('ABSPATH')) { exit(); } // No direct access
?>
#mobile_menu li.dbdb_secondary-menu { 
	display:none !important; 
}