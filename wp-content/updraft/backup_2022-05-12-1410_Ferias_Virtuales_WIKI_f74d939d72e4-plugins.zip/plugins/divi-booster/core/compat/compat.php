<?php
include(dirname(__FILE__).'/divi-icon-king/divi-icon-king.php');
include(dirname(__FILE__).'/munder-difflin/munder-difflin.php');
include(dirname(__FILE__).'/post-types-order/post-types-order.php');
include(dirname(__FILE__).'/wpml/wpml.php');