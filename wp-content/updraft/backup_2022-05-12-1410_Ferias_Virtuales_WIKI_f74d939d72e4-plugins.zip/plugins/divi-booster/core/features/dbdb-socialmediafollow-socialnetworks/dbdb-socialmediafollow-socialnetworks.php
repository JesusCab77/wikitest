<?php
/*
Plugin Name: Divi Booster Feature - Social Media Follow - Social Networks
Plugin URI: 
Description: Add more networks to the Social Media Follow module
Author: Divi Booster
Version: 0.1
Author URI: http://www.divibooster.com
*/

include_once(dirname(__FILE__).'/dbdb-socialmediafollow-socialnetworks-before.php');
include_once(dirname(__FILE__).'/dbdb-socialmediafollow-socialnetworks-main.php');

