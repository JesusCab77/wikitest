<?php
if (!defined('ABSPATH')) { exit(); } // No direct access
?>
.et_pb_slide_image, .et_pb_slide:first-child .et_pb_slide_image img.active {
	-webkit-animation-duration: 0s !important;
	animation-duration: 0s !important;
}