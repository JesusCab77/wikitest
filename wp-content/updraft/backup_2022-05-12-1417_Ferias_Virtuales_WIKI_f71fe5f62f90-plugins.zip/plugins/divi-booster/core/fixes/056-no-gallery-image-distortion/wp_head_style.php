<?php
if (!defined('ABSPATH')) { exit(); } // No direct access
?>
.et_pb_gallery_image img { 
    width: auto !important;
    height: auto !important;
    position: relative;
    left: 50% !important;
	-webkit-transform: translateX(-50%);
	-ms-transform: translateX(-50%);
	transform: translateX(-50%);
}